"""
License MIT

(c) Harold van Heukelum, 2023
"""
from .algorithm import GeneticAlgorithm

__version__ = '1.0.0'
__author__ = 'HJvH'
