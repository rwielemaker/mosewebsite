from .tetra_wrapper import TetraSolver

__version__ = '1.0.0'
__author__ = 'HJvH'
